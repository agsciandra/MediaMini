import { useState, useEffect, useCallback, useRef } from 'react';

const API = 'http://localhost:3001/api';
const POLL_MS = 1200;

function fmtBytes(b) {
  if (!b) return '—';
  if (b < 1024) return `${b} B`;
  if (b < 1048576) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1048576).toFixed(2)} MB`;
}

// ── Learn More Modal ──────────────────────────────────────────────────────────
function LearnMoreModal({ onClose }) {
  const handleBackdrop = (e) => { if (e.target === e.currentTarget) onClose(); };
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  return (
    <div style={m.backdrop} onClick={handleBackdrop}>
      <div style={m.panel}>
        <div style={m.header}>
          <span style={m.title}>How MediaMini works</span>
          <button style={m.close} onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div style={m.body}>
          <p style={m.para}>
            MediaMini has two modes. Optimize a Website crawls every page on a domain, discovers
            all images and videos, and processes them automatically. Optimize Local Files lets you
            drag in any images, videos, or zip archives directly — useful for assets behind a login,
            files not yet published, or anything outside a live URL.
          </p>
          <p style={m.para}>
            In both modes, every image is converted to WebP and every video to WebM by default.
            Local Files mode also supports PNG and MP4 output. Each file is then compressed using
            perceptual quality analysis — so it looks identical on screen but weighs far less.
          </p>
          <p style={m.para}>
            Before compressing, each image is classified by type (hero photo, illustration, icon,
            background texture, etc.) and given a compression target suited to that category.
            SSIM scoring then compares the output against the original pixel-by-pixel — if the
            visual difference is perceptible, the file is kept at a higher quality floor.
          </p>
          <p style={{ ...m.para, marginBottom: 0 }}>
            When the job finishes, your files download as a zip that mirrors your original folder
            structure exactly — drop the contents straight into your site as a replacement, with
            no renaming or reorganizing. Everything runs locally on your Mac. No files are uploaded
            anywhere.
          </p>
        </div>
      </div>
    </div>
  );
}

const m = {
  backdrop: { position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 },
  panel: { background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, maxWidth: 560, width: '100%', boxShadow: '0 24px 64px rgba(0,0,0,0.5)', display: 'flex', flexDirection: 'column' },
  header: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px 24px 16px', borderBottom: '1px solid var(--border)' },
  title: { fontSize: 15, fontWeight: 700, color: 'var(--text)' },
  close: { background: 'transparent', border: 'none', color: 'var(--muted)', fontSize: 14, cursor: 'pointer', padding: '4px 8px', borderRadius: 6, lineHeight: 1 },
  body: { padding: '20px 24px 24px', display: 'flex', flexDirection: 'column', gap: 0 },
  para: { fontSize: 13, color: 'var(--muted)', lineHeight: 1.75, marginBottom: 14 },
};

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  // Top-level mode: 'url' or 'local'
  const [appMode, setAppMode] = useState('url');

  // URL mode state
  const [url, setUrl] = useState('');
  const [crawlMode, setCrawlMode] = useState('site');
  const [urlError, setUrlError] = useState('');

  // Local mode state
  const [dragOver, setDragOver] = useState(false);
  const [localFiles, setLocalFiles] = useState([]); // File objects
  const [imageFormat, setImageFormat] = useState('webp');
  const [videoFormat, setVideoFormat] = useState('webm');
  const fileInputRef = useRef(null);

  // Shared job state
  const [jobId, setJobId] = useState(null);
  const [job, setJob] = useState(null);
  const [phase, setPhase] = useState('idle');
  const [autoDownloaded, setAutoDownloaded] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const pollRef = useRef(null);
  const logRef = useRef(null);

  // Auto-scroll log
  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [job?.log?.length]);

  // Auto-download when done
  useEffect(() => {
    if ((job?.status === 'done' || job?.status === 'complete') && job?.downloadReady && !autoDownloaded) {
      setAutoDownloaded(true);
      setTimeout(() => { window.location.href = `${API}/jobs/${jobId}/download`; }, 600);
    }
  }, [job?.status, job?.downloadReady, autoDownloaded, jobId]);

  const stopPoll = useCallback(() => {
    clearInterval(pollRef.current);
    pollRef.current = null;
  }, []);

  const poll = useCallback(async (id) => {
    try {
      const r = await fetch(`${API}/jobs/${id}`);
      if (!r.ok) { stopPoll(); return; }
      const d = await r.json();
      if (d.log && d.log.length > 600) d.log = d.log.slice(-600);
      setJob(d);
      if (d.status === 'done' || d.status === 'complete') { setPhase('done'); stopPoll(); }
      else if (d.status === 'error') { setPhase('error'); stopPoll(); }
    } catch (_) {}
  }, [stopPoll]);

  // ── URL job ──
  const handleStart = async () => {
    setUrlError('');
    const trimmed = url.trim();
    if (!trimmed) { setUrlError('Please enter a URL.'); return; }
    try {
      const r = await fetch(`${API}/jobs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: trimmed, crawlMode }),
      });
      const d = await r.json();
      if (!r.ok) { setUrlError(d.error || 'Failed to start.'); return; }
      setJobId(d.jobId);
      setJob(null);
      setPhase('running');
      setAutoDownloaded(false);
      pollRef.current = setInterval(() => poll(d.jobId), POLL_MS);
    } catch (_) {
      setUrlError('Cannot reach the MediaMini engine. Is the Terminal window still open?');
    }
  };

  // ── Local job ──
  const handleLocalStart = async () => {
    if (localFiles.length === 0) return;
    const formData = new FormData();
    for (const f of localFiles) formData.append('files', f);
    formData.append('imageFormat', imageFormat);
    formData.append('videoFormat', videoFormat);
    try {
      const r = await fetch(`${API}/local-jobs`, { method: 'POST', body: formData });
      const d = await r.json();
      if (!r.ok) { alert(d.error || 'Failed to start.'); return; }
      setJobId(d.jobId);
      setJob(null);
      setPhase('running');
      setAutoDownloaded(false);
      pollRef.current = setInterval(() => poll(d.jobId), POLL_MS);
    } catch (_) {
      alert('Cannot reach the MediaMini engine. Is the Terminal window still open?');
    }
  };

  const handleNew = async () => {
    stopPoll();
    if (jobId) try { await fetch(`${API}/jobs/${jobId}`, { method: 'DELETE' }); } catch (_) {}
    setJobId(null); setJob(null); setPhase('idle');
    setUrl(''); setUrlError(''); setAutoDownloaded(false);
    setLocalFiles([]);
  };

  // ── Drag and drop ──
  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const items = Array.from(e.dataTransfer.files);
    setLocalFiles(prev => {
      const names = new Set(prev.map(f => f.name + f.size));
      const fresh = items.filter(f => !names.has(f.name + f.size));
      return [...prev, ...fresh];
    });
  };

  const handleFileInput = (e) => {
    const items = Array.from(e.target.files);
    setLocalFiles(prev => {
      const names = new Set(prev.map(f => f.name + f.size));
      const fresh = items.filter(f => !names.has(f.name + f.size));
      return [...prev, ...fresh];
    });
    e.target.value = '';
  };

  const removeFile = (idx) => setLocalFiles(prev => prev.filter((_, i) => i !== idx));

  const pct = job?.metrics?.originalSize > 0
    ? Math.round(((job.metrics.originalSize - job.metrics.optimizedSize) / job.metrics.originalSize) * 100)
    : job?.metrics?.originalBytes > 0
    ? Math.round(((job.metrics.originalBytes - job.metrics.finalBytes) / job.metrics.originalBytes) * 100)
    : 0;

  const isIdle = phase === 'idle';
  const isDone = phase === 'done';
  const isError = phase === 'error';
  const isRunning = phase === 'running';

  const origBytes = job?.metrics?.originalSize || job?.metrics?.originalBytes;
  const optBytes = job?.metrics?.optimizedSize || job?.metrics?.finalBytes;

  return (
    <div style={s.root}>
      {showModal && <LearnMoreModal onClose={() => setShowModal(false)} />}

      {/* ── Header ── */}
      <header style={s.header}>
        <div style={s.headerInner}>
          <div style={s.brand}>
            <span style={s.brandName}>MediaMini</span>
          </div>
          <span style={s.brandTagline}>
            Converts and compresses every image and video on your site.{' '}
            <button style={s.learnMoreBtn} onClick={() => setShowModal(true)}>
              Learn more
            </button>
          </span>
        </div>
      </header>

      <main style={{ ...s.main, ...(isIdle ? { justifyContent: 'center' } : {}) }}>

        {/* ── Top-level mode tabs ── */}
        <div style={s.appTabRow}>
          <button
            style={{ ...s.appTab, ...(appMode === 'url' ? s.appTabActive : {}) }}
            onClick={() => { if (isIdle) setAppMode('url'); }}
            disabled={!isIdle}
          >
            Optimize a Website
          </button>
          <button
            style={{ ...s.appTab, ...(appMode === 'local' ? s.appTabActive : {}) }}
            onClick={() => { if (isIdle) setAppMode('local'); }}
            disabled={!isIdle}
          >
            Optimize Local Files
          </button>
        </div>

        {/* ── URL Mode Input Card ── */}
        {appMode === 'url' && (
          <div style={s.card}>
            <div style={s.modeRow}>
              <button
                style={{ ...s.modeBtn, ...(crawlMode === 'site' ? s.modeBtnActive : {}) }}
                onClick={() => { if (isIdle) setCrawlMode('site'); }}
                disabled={!isIdle}
              >
                Full Site
              </button>
              <button
                style={{ ...s.modeBtn, ...(crawlMode === 'page' ? s.modeBtnActive : {}) }}
                onClick={() => { if (isIdle) setCrawlMode('page'); }}
                disabled={!isIdle}
              >
                Single Page
              </button>
            </div>
            <p style={s.modeDesc}>
              {crawlMode === 'site'
                ? 'Crawls every page on the domain and optimizes all discovered media.'
                : 'Optimizes media found on this specific URL only.'}
            </p>
            <div style={s.inputRow}>
              <input
                style={{
                  ...s.input,
                  ...(urlError ? { borderColor: 'var(--error)' } : {}),
                  ...(!isIdle ? { opacity: 0.55, pointerEvents: 'none' } : {}),
                }}
                type="text"
                placeholder={crawlMode === 'site' ? 'https://alecsciandra.com' : 'https://alecsciandra.com/work'}
                value={url}
                onChange={e => { setUrl(e.target.value); setUrlError(''); }}
                onKeyDown={e => e.key === 'Enter' && isIdle && handleStart()}
                disabled={!isIdle}
                spellCheck={false}
              />
              {isIdle
                ? <button style={s.btnPrimary} onClick={handleStart}>Run</button>
                : <button style={s.btnSecondary} onClick={handleNew}>New Job</button>
              }
            </div>
            {urlError && <p style={s.errText}>{urlError}</p>}
          </div>
        )}

        {/* ── Local Files Mode Input Card ── */}
        {appMode === 'local' && (
          <div style={s.card}>
            {/* Format toggles */}
            <div style={s.formatRow}>
              <div style={s.formatGroup}>
                <span style={s.formatLabel}>Images</span>
                <div style={s.modeRow}>
                  <button
                    style={{ ...s.modeBtn, ...(imageFormat === 'webp' ? s.modeBtnActive : {}) }}
                    onClick={() => { if (isIdle) setImageFormat('webp'); }}
                    disabled={!isIdle}
                  >WebP</button>
                  <button
                    style={{ ...s.modeBtn, ...(imageFormat === 'png' ? s.modeBtnActive : {}) }}
                    onClick={() => { if (isIdle) setImageFormat('png'); }}
                    disabled={!isIdle}
                  >PNG</button>
                </div>
              </div>
              <div style={s.formatGroup}>
                <span style={s.formatLabel}>Videos</span>
                <div style={s.modeRow}>
                  <button
                    style={{ ...s.modeBtn, ...(videoFormat === 'webm' ? s.modeBtnActive : {}) }}
                    onClick={() => { if (isIdle) setVideoFormat('webm'); }}
                    disabled={!isIdle}
                  >WebM</button>
                  <button
                    style={{ ...s.modeBtn, ...(videoFormat === 'mp4' ? s.modeBtnActive : {}) }}
                    onClick={() => { if (isIdle) setVideoFormat('mp4'); }}
                    disabled={!isIdle}
                  >MP4</button>
                </div>
              </div>
            </div>

            {/* Drop zone */}
            {isIdle && (
              <div
                style={{
                  ...s.dropZone,
                  ...(dragOver ? s.dropZoneActive : {}),
                }}
                onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,video/*,.zip"
                  style={{ display: 'none' }}
                  onChange={handleFileInput}
                />
                <span style={s.dropIcon}>+</span>
                <span style={s.dropText}>
                  Drop files, folders, or a zip here
                </span>
                <span style={s.dropSub}>
                  or click to browse — images, videos, and zip archives accepted
                </span>
              </div>
            )}

            {/* File list */}
            {localFiles.length > 0 && (
              <div style={s.fileList}>
                {localFiles.map((f, i) => (
                  <div key={i} style={s.fileRow}>
                    <span style={s.fileName}>{f.name}</span>
                    <span style={s.fileSize}>{fmtBytes(f.size)}</span>
                    {isIdle && (
                      <button style={s.removeBtn} onClick={() => removeFile(i)}>✕</button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Action */}
            <div style={{ display: 'flex', gap: 10 }}>
              {isIdle
                ? <button
                    style={{ ...s.btnPrimary, ...(localFiles.length === 0 ? { opacity: 0.4, cursor: 'not-allowed' } : {}) }}
                    onClick={handleLocalStart}
                    disabled={localFiles.length === 0}
                  >
                    Run
                  </button>
                : <button style={s.btnSecondary} onClick={handleNew}>New Job</button>
              }
            </div>
          </div>
        )}

        {/* ── Progress + Metrics ── */}
        {job && (
          <div style={s.card}>
            <div style={s.statusRow}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                {isRunning && <span style={s.spinner} />}
                <span style={{
                  fontSize: 13, fontWeight: 600,
                  color: isDone ? 'var(--success)' : isError ? 'var(--error)' : 'var(--text)',
                }}>
                  {isRunning && 'Processing…'}
                  {isDone && 'Complete'}
                  {isError && 'Error'}
                </span>
              </div>
              <span style={s.progressPct}>{job.progress}%</span>
            </div>

            <div style={s.track}>
              <div style={{
                ...s.fill,
                width: `${job.progress}%`,
                background: isError
                  ? 'var(--error)'
                  : isDone
                  ? 'linear-gradient(90deg, var(--accent), var(--success))'
                  : 'var(--accent)',
              }} />
            </div>

            {/* Metrics — site mode gets 2-row 3-col grid, all others get single row */}
            {appMode === 'url' && crawlMode === 'site' ? (
              <div style={s.metricsGrid2}>
                <MetricTile label="Pages Crawled" value={job.metrics.pagesVisited || '—'} />
                <MetricTile label="Images" value={job.metrics.totalImages || '—'} />
                <MetricTile label="Videos" value={job.metrics.totalVideos || '—'} />
                <MetricTile label="Original Size" value={fmtBytes(origBytes)} />
                <MetricTile label="Optimized Size" value={fmtBytes(optBytes)} />
                <MetricTile label="Total Saved" value={origBytes > 0 ? `${pct}%` : '—'} highlight={isDone && pct > 0} />
              </div>
            ) : (
              <div style={s.metricsGrid}>
                <MetricTile label="Images" value={job.metrics.totalImages || '—'} />
                <MetricTile label="Videos" value={job.metrics.totalVideos || '—'} />
                <MetricTile label="Original Size" value={fmtBytes(origBytes)} />
                <MetricTile label="Optimized Size" value={fmtBytes(optBytes)} />
                <MetricTile label="Total Saved" value={origBytes > 0 ? `${pct}%` : '—'} highlight={isDone && pct > 0} />
              </div>
            )}

            {isDone && (
              <div style={s.downloadNotice}>
                <span>
                  {autoDownloaded
                    ? `Download started automatically — check your Downloads folder for ${job.zipFilename || job.zipName}`
                    : 'Preparing download…'}
                </span>
                <button
                  style={s.downloadAgain}
                  onClick={() => { window.location.href = `${API}/jobs/${jobId}/download`; }}
                >
                  Download again
                </button>
              </div>
            )}

            {isError && job.error && (
              <div style={s.errBox}>{job.error}</div>
            )}
          </div>
        )}

        {/* ── Live Log ── */}
        {job && (
          <div style={s.card}>
            <div style={s.logHeader}>
              <span style={s.sectionLabel}>Activity Log</span>
              {isRunning && <span style={s.livePill}>Live</span>}
            </div>
            <div style={s.logBox} ref={logRef}>
              {job.log.length === 0 && (
                <span style={{ color: 'var(--muted)', fontStyle: 'italic' }}>Waiting for activity…</span>
              )}
              {job.log.map((e, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, lineHeight: 1.5 }}>
                  <span style={s.logTime}>
                    {typeof e === 'string'
                      ? e.slice(0, 8)
                      : new Date(e.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                  <span style={{ color: typeof e === 'string' ? 'var(--muted)' : logColor(e.type), flex: 1 }}>
                    {typeof e === 'string' ? e.slice(9) : e.message}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

      </main>

      <footer style={s.footer}>
        MediaMini — <a href="https://alecsciandra.com" target="_blank" rel="noreferrer" style={{ color: 'inherit', textDecoration: 'underline', textUnderlineOffset: 2 }}>alecsciandra.com</a>
      </footer>
    </div>
  );
}

function MetricTile({ label, value, highlight }) {
  return (
    <div style={{
      ...s.metricTile,
      ...(highlight ? { borderColor: 'var(--success)', background: 'rgba(62,207,142,0.06)' } : {}),
    }}>
      <span style={s.metricValue}>{value}</span>
      <span style={s.metricLabel}>{label}</span>
    </div>
  );
}

function logColor(type) {
  if (type === 'success') return 'var(--success)';
  if (type === 'warn') return 'var(--warn)';
  if (type === 'error') return 'var(--error)';
  if (type === 'crawl') return 'var(--accent)';
  return 'var(--muted)';
}

// ── Styles ────────────────────────────────────────────────────────────────────
const s = {
  root: { minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--bg)' },

  header: { borderBottom: '1px solid var(--border)', background: 'var(--surface)', padding: '0 24px' },
  headerInner: { maxWidth: 900, margin: '0 auto', display: 'flex', alignItems: 'center', gap: 20, height: 64 },
  brand: { display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 },
  brandName: { fontSize: 16, fontWeight: 700, letterSpacing: '-0.3px', color: 'var(--text)' },
  brandTagline: { fontSize: 12, color: 'var(--muted)', lineHeight: 1.5 },

  learnMoreBtn: {
    background: 'transparent', border: 'none',
    color: 'var(--accent)', fontSize: 12,
    cursor: 'pointer', padding: 0,
    textDecoration: 'underline', textUnderlineOffset: 2,
    fontFamily: 'var(--font)',
  },

  main: {
    flex: 1, maxWidth: 900, width: '100%',
    margin: '0 auto', padding: '32px 24px',
    display: 'flex', flexDirection: 'column', gap: 20,
  },

  // Top-level app mode tabs
  appTabRow: {
    display: 'flex', gap: 4,
    background: 'var(--surface)', border: '1px solid var(--border)',
    borderRadius: 10, padding: 4, alignSelf: 'flex-start',
  },
  appTab: {
    background: 'transparent', border: 'none',
    borderRadius: 7, padding: '8px 20px',
    fontSize: 13, fontWeight: 500, color: 'var(--muted)',
    cursor: 'pointer', transition: 'all 0.15s',
  },
  appTabActive: {
    background: 'var(--surface2)',
    color: 'var(--text)', fontWeight: 600,
    boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
  },

  card: {
    background: 'var(--surface)', border: '1px solid var(--border)',
    borderRadius: 14, padding: '24px 28px',
    display: 'flex', flexDirection: 'column', gap: 16,
  },

  modeRow: { display: 'flex', gap: 4, background: 'var(--surface2)', borderRadius: 8, padding: 3, alignSelf: 'flex-start' },
  modeBtn: {
    background: 'transparent', border: 'none',
    borderRadius: 6, padding: '7px 18px',
    fontSize: 13, fontWeight: 500, color: 'var(--muted)',
    cursor: 'pointer', transition: 'all 0.15s',
  },
  modeBtnActive: {
    background: 'var(--surface3)',
    color: 'var(--text)', fontWeight: 600,
    boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
  },
  modeDesc: { fontSize: 13, color: 'var(--muted)', marginTop: -4 },

  // Format toggles (local mode)
  formatRow: { display: 'flex', gap: 24, flexWrap: 'wrap' },
  formatGroup: { display: 'flex', flexDirection: 'column', gap: 6 },
  formatLabel: { fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px', color: 'var(--muted)' },

  // Drop zone
  dropZone: {
    border: '1.5px dashed var(--border)',
    borderRadius: 12, padding: '36px 24px',
    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
    cursor: 'pointer', transition: 'border-color 0.15s, background 0.15s',
    background: 'transparent',
  },
  dropZoneActive: {
    borderColor: 'var(--accent)',
    background: 'rgba(79,142,247,0.05)',
  },
  dropIcon: { fontSize: 28, color: 'var(--muted)', lineHeight: 1, fontWeight: 300 },
  dropText: { fontSize: 14, fontWeight: 500, color: 'var(--text)' },
  dropSub: { fontSize: 12, color: 'var(--muted)' },

  // File list
  fileList: {
    display: 'flex', flexDirection: 'column', gap: 4,
    maxHeight: 180, overflowY: 'auto',
    border: '1px solid var(--border)', borderRadius: 9,
    padding: '8px 12px',
  },
  fileRow: {
    display: 'flex', alignItems: 'center', gap: 10,
    padding: '4px 0', borderBottom: '1px solid rgba(255,255,255,0.04)',
  },
  fileName: { flex: 1, fontSize: 12, color: 'var(--text)', fontFamily: 'var(--mono)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  fileSize: { fontSize: 11, color: 'var(--muted)', flexShrink: 0, fontFamily: 'var(--mono)' },
  removeBtn: {
    background: 'transparent', border: 'none',
    color: 'var(--muted)', fontSize: 11, cursor: 'pointer',
    padding: '2px 6px', borderRadius: 4, flexShrink: 0,
  },

  inputRow: { display: 'flex', gap: 10 },
  input: {
    flex: 1,
    background: 'var(--surface2)', border: '1px solid var(--border)',
    borderRadius: 9, padding: '12px 16px',
    color: 'var(--text)', fontSize: 14,
    fontFamily: 'var(--font)', outline: 'none',
    transition: 'border-color 0.15s',
  },
  btnPrimary: {
    background: 'var(--accent)', color: '#fff',
    border: 'none', borderRadius: 9,
    padding: '12px 28px', fontSize: 14, fontWeight: 600,
    cursor: 'pointer', whiteSpace: 'nowrap',
    transition: 'opacity 0.15s',
  },
  btnSecondary: {
    background: 'var(--surface2)', color: 'var(--muted)',
    border: '1px solid var(--border)', borderRadius: 9,
    padding: '12px 24px', fontSize: 14, fontWeight: 500,
    cursor: 'pointer', whiteSpace: 'nowrap',
  },
  errText: { color: 'var(--error)', fontSize: 13, marginTop: -8 },

  statusRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  progressPct: { fontFamily: 'var(--mono)', fontWeight: 700, fontSize: 13, color: 'var(--muted)' },
  track: { height: 6, background: 'var(--surface2)', borderRadius: 3, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 3, transition: 'width 0.5s ease, background 0.4s ease' },

  spinner: {
    display: 'inline-block', width: 12, height: 12,
    border: '2px solid var(--border)', borderTopColor: 'var(--accent)',
    borderRadius: '50%', animation: 'spin 0.7s linear infinite',
  },

  metricsGrid: { display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 },
  metricsGrid2: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 },
  metricTile: {
    background: 'var(--surface2)', border: '1px solid var(--border)',
    borderRadius: 10, padding: '14px 16px',
    display: 'flex', flexDirection: 'column', gap: 4,
    transition: 'border-color 0.3s, background 0.3s',
  },
  metricValue: { fontSize: 20, fontWeight: 700, fontFamily: 'var(--mono)', color: 'var(--text)' },
  metricLabel: { fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.6px' },

  downloadNotice: {
    display: 'flex', alignItems: 'center', gap: 10,
    background: 'rgba(62,207,142,0.07)', border: '1px solid rgba(62,207,142,0.2)',
    borderRadius: 9, padding: '12px 16px', fontSize: 13, color: 'var(--success)',
  },
  downloadAgain: {
    marginLeft: 'auto', background: 'transparent',
    border: '1px solid rgba(62,207,142,0.3)', borderRadius: 6,
    padding: '5px 12px', fontSize: 12, color: 'var(--success)',
    cursor: 'pointer', whiteSpace: 'nowrap',
  },

  errBox: {
    background: 'rgba(224,82,82,0.08)', border: '1px solid rgba(224,82,82,0.25)',
    borderRadius: 9, padding: '12px 16px',
    color: 'var(--error)', fontSize: 13, fontFamily: 'var(--mono)',
  },

  logHeader: { display: 'flex', alignItems: 'center', gap: 10 },
  sectionLabel: { fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', color: 'var(--muted)' },
  livePill: {
    fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px',
    background: 'rgba(79,142,247,0.15)', color: 'var(--accent)',
    border: '1px solid rgba(79,142,247,0.3)', borderRadius: 4,
    padding: '2px 7px',
  },
  logBox: {
    background: 'var(--bg)', border: '1px solid var(--border)',
    borderRadius: 9, padding: '14px 16px',
    height: 260, overflowY: 'auto',
    display: 'flex', flexDirection: 'column', gap: 4,
    fontFamily: 'var(--mono)', fontSize: 12,
  },
  logTime: { color: '#3a4255', flexShrink: 0, userSelect: 'none' },

  footer: {
    borderTop: '1px solid var(--border)',
    padding: '16px 32px', textAlign: 'center',
    fontSize: 12, color: '#3a4255',
  },
};
