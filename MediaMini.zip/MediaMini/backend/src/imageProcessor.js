'use strict';

const sharp = require('sharp');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');

// Allow sharp to use all available CPU cores
sharp.concurrency(0);

// HTTP keep-alive agents for connection reuse across image downloads
const httpAgent  = new http.Agent({ keepAlive: true, maxSockets: 20 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 20 });

// ─── Per-category quality configuration ──────────────────────────────────────
const CATEGORIES = {
  hero:       { ssimThreshold: 0.985, qualityStart: 90, qualityMin: 75, label: 'Hero Image' },
  photo:      { ssimThreshold: 0.975, qualityStart: 87, qualityMin: 68, label: 'Photograph' },
  graphic:    { ssimThreshold: 0.970, qualityStart: 82, qualityMin: 60, label: 'Graphic / Illustration' },
  icon:       { ssimThreshold: 0.960, qualityStart: 78, qualityMin: 52, label: 'Icon / UI Element' },
  background: { ssimThreshold: 0.960, qualityStart: 78, qualityMin: 50, label: 'Background Texture' },
};

// Tiered pipeline thresholds
const SSIM_SIZE       = 256;   // Downsample to this before SSIM comparison
const MAX_DIM         = 3000;  // Resize if image exceeds this
const SKIP_BYTES      = 4 * 1024;    // Under 4 KB: just convert, no compression
const FAST_PATH_BYTES = 200 * 1024;  // Under 200 KB: single-pass, no SSIM

/**
 * Fetch a URL with up to 2 retries on network/CDN errors.
 * Waits 1 second between attempts.
 */
async function fetchWithRetry(url, options, retries = 2) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await axios.get(url, options);
    } catch (err) {
      if (attempt === retries) throw err;
      await new Promise(r => setTimeout(r, 1000));
    }
  }
}

async function processImage(imageUrl, outputDir, filename) {
  if (/\.svg(\?|$)/i.test(imageUrl)) {
    throw new Error('SVG files are skipped (vector format)');
  }

  const res = await fetchWithRetry(imageUrl, {
    responseType: 'arraybuffer',
    timeout: 15000,
    maxContentLength: 500 * 1024 * 1024,
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; MediaMini/1.0)' },
    httpAgent,
    httpsAgent,
  });

  const input = Buffer.from(res.data);
  const originalSize = input.length;

  let meta;
  try {
    meta = await sharp(input).metadata();
  } catch (err) {
    throw new Error(`Cannot read image: ${err.message}`);
  }

  const { width = 0, height = 0 } = meta;
  const category = await classifyImage(input, width, height);
  const cfg = CATEGORIES[category];
  const outPath = path.join(outputDir, filename);

  // ── Tier 0: Tiny files — just convert format ──
  if (originalSize < SKIP_BYTES) {
    await sharp(input).webp({ quality: cfg.qualityStart, effort: 3 }).toFile(outPath);
    const finalSize = fs.statSync(outPath).size;
    return { outputPath: outPath, originalSize, finalSize, ssim: 1.0, category, categoryLabel: cfg.label };
  }

  // Prepare base pipeline (resize if needed)
  let base = sharp(input);
  if (width > MAX_DIM || height > MAX_DIM) {
    base = base.resize(MAX_DIM, MAX_DIM, { fit: 'inside', withoutEnlargement: true });
  }

  // Decode input once and reuse the raw buffer — avoids re-decoding on every encode pass
  const rawFull = await base.clone().raw().toBuffer({ resolveWithObject: true });

  // ── Tier 1: Small/medium files — single-pass compression, no SSIM ──
  if (originalSize < FAST_PATH_BYTES) {
    // Use a quality midpoint between start and min for a fast single-pass
    const fastQuality = Math.round((cfg.qualityStart + cfg.qualityMin) / 2);
    const buf = await sharp(rawFull.data, { raw: rawFull.info })
      .webp({ quality: fastQuality, effort: 3, smartSubsample: true })
      .toBuffer();
    const finalBuf = buf.length < originalSize ? buf
      : await sharp(rawFull.data, { raw: rawFull.info }).webp({ quality: cfg.qualityStart, effort: 3 }).toBuffer();
    await fs.promises.writeFile(outPath, finalBuf);
    return { outputPath: outPath, originalSize, finalSize: finalBuf.length, ssim: cfg.ssimThreshold, category, categoryLabel: cfg.label };
  }

  // ── Tier 2: Large files — binary search with downsampled SSIM ──
  // Downsample reference once for SSIM (much faster than full-res comparison)
  const refSmall = await sharp(rawFull.data, { raw: rawFull.info })
    .resize(SSIM_SIZE, SSIM_SIZE, { fit: 'inside', withoutEnlargement: true })
    .raw()
    .toBuffer({ resolveWithObject: true });

  // Safe fallback at qualityStart — encode once and cache
  const safeBuffer = await sharp(rawFull.data, { raw: rawFull.info })
    .webp({ quality: cfg.qualityStart, effort: 3 })
    .toBuffer();

  let bestBuffer = safeBuffer;
  let bestSsim = cfg.ssimThreshold;
  let bestQuality = cfg.qualityStart;

  let lo = cfg.qualityMin;
  let hi = cfg.qualityStart - 1; // Start one below qualityStart since we already have it cached

  while (lo <= hi) {
    const mid = Math.floor((lo + hi) / 2);

    const candidate = await sharp(rawFull.data, { raw: rawFull.info })
      .webp({ quality: mid, effort: 3, smartSubsample: true, nearLossless: false })
      .toBuffer();

    // Downsample candidate to same SSIM size before comparison
    const candSmall = await sharp(candidate)
      .resize(SSIM_SIZE, SSIM_SIZE, { fit: 'inside', withoutEnlargement: true })
      .raw()
      .toBuffer({ resolveWithObject: true });

    // Dimension mismatch guard
    if (refSmall.info.width !== candSmall.info.width || refSmall.info.height !== candSmall.info.height) {
      bestBuffer = safeBuffer;
      bestQuality = cfg.qualityStart;
      break;
    }

    const ssim = computeSSIM(refSmall.data, candSmall.data, refSmall.info.width, refSmall.info.height, refSmall.info.channels);

    if (ssim >= cfg.ssimThreshold) {
      bestBuffer = candidate;
      bestSsim = ssim;
      bestQuality = mid;
      hi = mid - 1;
    } else {
      lo = mid + 1;
    }
  }

  // If compressed is larger than original, use safe quality
  if (bestBuffer.length >= originalSize) {
    bestBuffer = safeBuffer;
    bestQuality = cfg.qualityStart;
  }

  await fs.promises.writeFile(outPath, bestBuffer);

  return {
    outputPath: outPath,
    originalSize,
    finalSize: bestBuffer.length,
    ssim: bestSsim,
    quality: bestQuality,
    category,
    categoryLabel: cfg.label,
  };
}

// ─── Image Classification ─────────────────────────────────────────────────────
//
// Thresholds are empirically tuned for typical web assets. To adjust:
//
//   entropy        — Shannon entropy of the luminance histogram (0–8).
//                    Low = flat/simple (icons, gradients). High = complex (photos, textures).
//                    Typical ranges: icons ~3–5, illustrations ~5–6.5, photos ~6.5–7.5
//
//   uniqueColorRatio — distinct quantized colors / total pixels (0–1).
//                    Low = few colors (logos, flat UI). High = many colors (photography).
//                    Typical ranges: flat graphics <0.08, photos >0.15
//
//   edgeDensity    — fraction of pixels with a luminance gradient > 20 (0–1).
//                    High = sharp edges (illustrations, UI). Low = smooth gradients (photos, blurs).
//                    Typical ranges: illustrations >0.12, photos 0.05–0.10
//
//   area           — pixel area (width × height). Used to separate large hero/background
//                    images from small UI elements at the same entropy level.
//
// Known edge cases:
//   - High-contrast illustrations (e.g. bold duotone) may have photo-level entropy
//     and get classified as 'photo'. This is conservative (higher quality floor) — acceptable.
//   - Very dark or very light photos may have low entropy and be classified as 'background'.
//     The quality difference between 'background' and 'photo' is small enough to be harmless.
async function classifyImage(input, width, height) {
  const area = width * height;

  // Fast path: small dimensions → icon, no analysis needed
  if (width <= 128 || height <= 128 || area < 20000) return 'icon';

  const aspect = width / Math.max(height, 1);
  const { entropy, uniqueColorRatio, edgeDensity } = await analyzeContent(input);

  // Hero: large, wide, photographic — requires content analysis to avoid misclassifying
  // wide banner illustrations as hero images (they'd get unnecessarily high quality floor)
  if (area > 800000 && aspect >= 1.6 && entropy > 5.5 && uniqueColorRatio > 0.08) return 'hero';

  // Photo: high entropy + high color variety = real photographic content
  if (entropy > 6.5 && uniqueColorRatio > 0.15) return 'photo';

  // Icon: low entropy + few colors = flat, simple UI element
  if (entropy < 5.0 && uniqueColorRatio < 0.08) return 'icon';

  // Graphic/illustration: moderate entropy but sharp edges = drawn/vector-style content
  if (entropy < 5.8 && edgeDensity > 0.12) return 'graphic';

  // Background: large, moderate entropy, not wide = texture or ambient fill
  if (area > 400000 && entropy < 6.0 && aspect < 1.5) return 'background';

  // Default: treat as photo (conservative — higher quality floor)
  return 'photo';
}

async function analyzeContent(input) {
  const sampleSize = 120;
  // Force sRGB 3-channel to handle CMYK, grayscale, and other formats correctly
  const raw = await sharp(input)
    .resize(sampleSize, sampleSize, { fit: 'fill' })
    .toColorspace('srgb')
    .removeAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const data = raw.data;
  const ch = raw.info.channels;
  const n = sampleSize * sampleSize;

  const hist = new Float32Array(256).fill(0);
  const colorSet = new Set();
  const lums = new Uint8Array(n);

  // Single pass: compute luminance, histogram, and color set simultaneously
  for (let i = 0; i < n; i++) {
    const p = i * ch;
    const r = data[p], g = data[p + 1] || 0, b = data[p + 2] || 0;
    const lum = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
    lums[i] = lum;
    hist[lum]++;
    const qr = Math.round(r / 16), qg = Math.round(g / 16), qb = Math.round(b / 16);
    colorSet.add((qr << 8) | (qg << 4) | qb);
  }

  let entropy = 0;
  for (let i = 0; i < 256; i++) {
    if (hist[i] > 0) {
      const p = hist[i] / n;
      entropy -= p * Math.log2(p);
    }
  }

  const uniqueColorRatio = colorSet.size / n;

  // Edge density pass (uses pre-computed lums from above)
  let edgeCount = 0;
  for (let y = 1; y < sampleSize - 1; y++) {
    for (let x = 1; x < sampleSize - 1; x++) {
      const idx = y * sampleSize + x;
      const diff = Math.abs(lums[idx] - lums[idx + 1]) + Math.abs(lums[idx] - lums[idx + sampleSize]);
      if (diff > 20) edgeCount++;
    }
  }
  const edgeDensity = edgeCount / n;

  return { entropy, uniqueColorRatio, edgeDensity };
}

// ─── SSIM (operates on downsampled thumbnails for speed) ─────────────────────
function computeSSIM(a, b, w, h, ch) {
  const n = w * h;
  const lumA = new Float32Array(n);
  const lumB = new Float32Array(n);

  for (let i = 0; i < n; i++) {
    const p = i * ch;
    lumA[i] = ch >= 3 ? 0.299 * a[p] + 0.587 * a[p + 1] + 0.114 * a[p + 2] : a[p];
    lumB[i] = ch >= 3 ? 0.299 * b[p] + 0.587 * b[p + 1] + 0.114 * b[p + 2] : b[p];
  }

  let mA = 0, mB = 0;
  for (let i = 0; i < n; i++) { mA += lumA[i]; mB += lumB[i]; }
  mA /= n; mB /= n;

  let vA = 0, vB = 0, cov = 0;
  for (let i = 0; i < n; i++) {
    const da = lumA[i] - mA, db = lumB[i] - mB;
    vA += da * da; vB += db * db; cov += da * db;
  }
  vA /= n; vB /= n; cov /= n;

  const C1 = (0.01 * 255) ** 2, C2 = (0.03 * 255) ** 2;
  return Math.max(0, Math.min(1,
    ((2 * mA * mB + C1) * (2 * cov + C2)) / ((mA ** 2 + mB ** 2 + C1) * (vA + vB + C2))
  ));
}

/**
 * processLocalImage — same perceptual pipeline but reads from a local file path
 * and supports both WebP and PNG output.
 * @param {string} inputPath  - absolute path to source image file
 * @param {string} outputPath - absolute path for output file
 * @param {string} format     - 'webp' | 'png'
 * @returns {object} { outputPath, originalSize, outputSize, ssim, category, categoryLabel }
 */
async function processLocalImage(inputPath, outputPath, format = 'webp') {
  const ext = path.extname(inputPath).toLowerCase();
  if (ext === '.svg') throw new Error('SVG files are skipped (vector format)');

  const input = await fs.promises.readFile(inputPath);
  const originalSize = input.length;

  let meta;
  try {
    meta = await sharp(input).metadata();
  } catch (err) {
    throw new Error(`Cannot read image: ${err.message}`);
  }

  // Normalize to sRGB to handle CMYK/grayscale edge cases
  const normalized = await sharp(input).toColorspace('srgb').toBuffer();

  const { width = 0, height = 0 } = meta;
  const category = await classifyImage(normalized, width, height);
  const cfg = CATEGORIES[category];

  const encode = (buf, quality) =>
    format === 'png'
      ? sharp(buf).png({ compressionLevel: Math.round((100 - quality) / 10), adaptiveFiltering: true })
      : sharp(buf).webp({ quality, effort: 3, smartSubsample: true });

  // Tier 0: tiny files — just convert
  if (originalSize < SKIP_BYTES) {
    await encode(normalized, cfg.qualityStart).toFile(outputPath);
    const outputSize = fs.statSync(outputPath).size;
    return { outputPath, originalSize, outputSize, ssim: 1.0, category, categoryLabel: cfg.label };
  }

  let base = sharp(normalized);
  if (width > MAX_DIM || height > MAX_DIM) {
    base = base.resize(MAX_DIM, MAX_DIM, { fit: 'inside', withoutEnlargement: true });
  }
  const rawFull = await base.clone().raw().toBuffer({ resolveWithObject: true });

  // Tier 1: small/medium — single-pass
  if (originalSize < FAST_PATH_BYTES) {
    const fastQuality = Math.round((cfg.qualityStart + cfg.qualityMin) / 2);
    const buf = await encode(rawFull.data, fastQuality).toBuffer();
    const finalBuf = buf.length < originalSize ? buf
      : await encode(rawFull.data, cfg.qualityStart).toBuffer();
    await fs.promises.writeFile(outputPath, finalBuf);
    return { outputPath, originalSize, outputSize: finalBuf.length, ssim: cfg.ssimThreshold, category, categoryLabel: cfg.label };
  }

  // Tier 2: large — binary search with SSIM
  const refSmall = await sharp(rawFull.data, { raw: rawFull.info })
    .resize(SSIM_SIZE, SSIM_SIZE, { fit: 'inside', withoutEnlargement: true })
    .raw().toBuffer({ resolveWithObject: true });

  const safeBuffer = await encode(rawFull.data, cfg.qualityStart).toBuffer();
  let bestBuffer = safeBuffer;
  let bestSsim = cfg.ssimThreshold;
  let lo = cfg.qualityMin;
  let hi = cfg.qualityStart - 1;

  while (lo <= hi) {
    const mid = Math.floor((lo + hi) / 2);
    const candidate = await encode(rawFull.data, mid).toBuffer();
    const candSmall = await sharp(candidate)
      .resize(SSIM_SIZE, SSIM_SIZE, { fit: 'inside', withoutEnlargement: true })
      .raw().toBuffer({ resolveWithObject: true });

    if (refSmall.info.width !== candSmall.info.width || refSmall.info.height !== candSmall.info.height) {
      bestBuffer = safeBuffer;
      break;
    }

    const ssim = computeSSIM(refSmall.data, candSmall.data, refSmall.info.width, refSmall.info.height, refSmall.info.channels);
    if (ssim >= cfg.ssimThreshold) {
      bestBuffer = candidate;
      bestSsim = ssim;
      hi = mid - 1;
    } else {
      lo = mid + 1;
    }
  }

  if (bestBuffer.length >= originalSize) bestBuffer = safeBuffer;
  await fs.promises.writeFile(outputPath, bestBuffer);

  return { outputPath, originalSize, outputSize: bestBuffer.length, ssim: bestSsim, category, categoryLabel: cfg.label };
}

module.exports = { processImage, processLocalImage };
