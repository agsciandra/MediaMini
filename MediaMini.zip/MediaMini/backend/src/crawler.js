'use strict';

const { chromium } = require('playwright');
const { URL } = require('url');

const MAX_PAGES = 200;
const CONCURRENCY = 3;

/**
 * crawlSite — crawl an entire domain
 * @param {string} startUrl
 * @param {function} onProgress
 * @returns {object} siteMap + pageCount
 */
async function crawlSite(startUrl, onProgress) {
  return _crawl(startUrl, onProgress, false);
}

/**
 * crawlPage — scrape a single page only
 * @param {string} pageUrl
 * @param {function} onProgress
 * @returns {object} siteMap + pageCount
 */
async function crawlPage(pageUrl, onProgress) {
  return _crawl(pageUrl, onProgress, true);
}

// Common ISO 639-1 locale codes used as path prefixes (e.g. /fr/, /de/, /ja/)
const LOCALE_PREFIXES = new Set([
  'af','sq','am','ar','hy','az','eu','be','bn','bs','bg','ca','ceb','zh','co','hr','cs',
  'da','nl','en','eo','et','fi','fr','fy','gl','ka','de','el','gu','ht','ha','haw','he',
  'hi','hmn','hu','is','ig','id','ga','it','ja','jv','kn','kk','km','rw','ko','ku','ky',
  'lo','la','lv','lt','lb','mk','mg','ms','ml','mt','mi','mr','mn','my','ne','no','ny',
  'or','ps','fa','pl','pt','pa','ro','ru','sm','gd','sr','st','sn','sd','si','sk','sl',
  'so','es','su','sw','sv','tl','tg','ta','tt','te','th','tr','tk','uk','ur','ug','uz',
  'vi','cy','xh','yi','yo','zu',
]);

/**
 * Strip locale prefix and lang/locale query params so that
 * /fr/projects/mujin and /projects/mujin are treated as the same page.
 */
function normalizeLocaleUrl(href) {
  try {
    const u = new URL(href);
    // Remove hash
    u.hash = '';
    // Remove lang/locale/hl query params
    u.searchParams.delete('lang');
    u.searchParams.delete('locale');
    u.searchParams.delete('hl');
    // Strip leading locale path segment: /fr/projects → /projects
    const segments = u.pathname.split('/').filter(Boolean);
    if (segments.length > 0 && LOCALE_PREFIXES.has(segments[0].toLowerCase())) {
      u.pathname = '/' + segments.slice(1).join('/');
    }
    // Remove trailing slash for consistent dedup
    return u.href.replace(/\/$/, '');
  } catch (_) {
    return href;
  }
}

async function _crawl(startUrl, onProgress, singlePage) {
  const base = new URL(startUrl);
  const origin = base.origin;
  const visited = new Set();   // stores normalized URLs
  const queue = [startUrl];
  const results = {};

  const browser = await chromium.launch({ headless: true });
  // Reuse a single context across all pages — creating a new context per page is expensive
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (compatible; MediaMini/1.0)',
  });

  async function processPage(pageUrl) {
    const normalizedUrl = normalizeLocaleUrl(pageUrl);
    if (visited.has(normalizedUrl) || visited.size >= MAX_PAGES) return;
    visited.add(normalizedUrl);
    onProgress({ type: 'crawl', message: `Crawling: ${pageUrl}`, visited: visited.size });

    const page = await ctx.newPage();
    const images = new Set();
    const videos = new Set();
    let is404 = false;

    try {
      const response = await page.goto(pageUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      // Detect 404 (and other 4xx/5xx) — still collect media but tag the page
      if (response && response.status() === 404) {
        is404 = true;
        onProgress({ type: 'warn', message: `404 page detected: ${pageUrl} — collecting media into 404/ folder` });
      }

      // img src
      const imgs = await page.$$eval('img[src]', els => els.map(e => e.src));
      imgs.forEach(src => tryAdd(src, pageUrl, 'image', images));

      // picture / source srcset
      const srcsets = await page.$$eval('source[srcset]', els => els.map(e => e.srcset));
      srcsets.forEach(ss =>
        ss.split(',').forEach(p => tryAdd(p.trim().split(/\s+/)[0], pageUrl, 'image', images))
      );

      // video src / source
      const vids = await page.$$eval('video, video source', els =>
        els.map(e => e.src || e.getAttribute('src')).filter(Boolean)
      ).catch(() => []);
      vids.forEach(src => tryAdd(src, pageUrl, 'video', videos));

      // CSS background-image
      const bgs = await page.evaluate(() => {
        const urls = [];
        document.querySelectorAll('*').forEach(el => {
          const bg = getComputedStyle(el).backgroundImage;
          if (bg && bg !== 'none') {
            const m = bg.match(/url\(["']?([^"')]+)/);
            if (m) urls.push(m[1]);
          }
        });
        return urls;
      });
      bgs.forEach(src => tryAdd(src, pageUrl, 'image', images));

      // Collect links for full-site mode
      if (!singlePage) {
        const links = await page.$$eval('a[href]', els => els.map(e => e.href));
        links.forEach(href => {
          try {
            const u = new URL(href);
            if (u.origin === origin) {
              const normalized = normalizeLocaleUrl(u.href);
              // Skip if already visited or already queued (using normalized form for dedup)
              if (!visited.has(normalized) && !queue.some(q => normalizeLocaleUrl(q) === normalized)) {
                queue.push(u.href); // queue the original href so the real page loads correctly
              }
            }
          } catch (_) {}
        });
      }
    } catch (err) {
      onProgress({ type: 'warn', message: `Could not crawl ${pageUrl}: ${err.message}` });
    } finally {
      await page.close();
    }

    results[pageUrl] = { images: [...images], videos: [...videos], is404 };
  }

  while (queue.length > 0 && visited.size < MAX_PAGES) {
    const batch = queue.splice(0, CONCURRENCY);
    await Promise.all(batch.map(u => processPage(u)));
  }

  await ctx.close();
  await browser.close();

  // Deduplicate media across pages
  const seen = new Set();
  const out = {};
  for (const [pg, { images, videos, is404 }] of Object.entries(results)) {
    const ui = images.filter(u => !seen.has(u) && !!seen.add(u));
    const uv = videos.filter(u => !seen.has(u) && !!seen.add(u));
    if (ui.length || uv.length) out[pg] = { images: ui, videos: uv, is404: !!is404 };
  }

  return { siteMap: out, pageCount: visited.size };
}

function tryAdd(src, base, type, set) {
  try {
    const u = new URL(src, base);
    const lower = u.href.toLowerCase().split('?')[0];
    // Skip SVGs
    if (/\.svg$/.test(lower)) return;
    if (type === 'image' && /\.(jpe?g|png|gif|webp|bmp|tiff?|avif)$/.test(lower)) set.add(u.href);
    if (type === 'video' && /\.(mp4|webm|mov|avi|mkv|ogv|m4v)$/.test(lower)) set.add(u.href);
  } catch (_) {}
}

module.exports = { crawlSite, crawlPage };
