'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const AdmZip = require('adm-zip');
const { processLocalImage } = require('./imageProcessor');
const { processLocalVideo } = require('./videoProcessor');

const IMAGE_EXTS = new Set(['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.tif', '.avif', '.webp']);
const VIDEO_EXTS = new Set(['.mp4', '.mov', '.avi', '.mkv', '.ogv', '.m4v', '.webm']);

/**
 * Run a local file job.
 * @param {object} job - job object from jobManager
 * @param {string[]} uploadedPaths - absolute paths to uploaded files/folders
 * @param {string} imageFormat - 'webp' | 'png'
 * @param {string} videoFormat - 'webm' | 'mp4'
 * @param {function} addLog - logging helper
 */
async function runLocalJob(job, uploadedPaths, imageFormat, videoFormat, addLog) {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mediamini-local-'));

  try {
    // Collect all media files from uploaded paths (expand zips and folders)
    const mediaFiles = []; // { srcPath, relPath }
    for (const uploadedPath of uploadedPaths) {
      await collectFiles(uploadedPath, uploadedPath, mediaFiles, addLog, job);
    }

    job.metrics.totalImages = mediaFiles.filter(f => IMAGE_EXTS.has(path.extname(f.srcPath).toLowerCase())).length;
    job.metrics.totalVideos = mediaFiles.filter(f => VIDEO_EXTS.has(path.extname(f.srcPath).toLowerCase())).length;
    addLog(job, 'info', `Found ${job.metrics.totalImages} images and ${job.metrics.totalVideos} videos`);

    let origTotal = 0;
    let optTotal = 0;

    for (const { srcPath, relPath } of mediaFiles) {
      const ext = path.extname(srcPath).toLowerCase();
      const baseName = path.basename(relPath, ext);
      const relDir = path.dirname(relPath);
      const outDir = path.join(tempDir, relDir);
      fs.mkdirSync(outDir, { recursive: true });

      const srcStat = fs.statSync(srcPath);
      origTotal += srcStat.size;

      if (IMAGE_EXTS.has(ext)) {
        const outExt = imageFormat === 'png' ? '.png' : '.webp';
        const outPath = path.join(outDir, baseName + outExt);
        try {
          const result = await processLocalImage(srcPath, outPath, imageFormat === 'png' ? 'png' : 'webp');
          const saved = srcStat.size - result.outputSize;
          const pct = Math.round((saved / srcStat.size) * 100);
          optTotal += result.outputSize;
          addLog(job, 'info', `[${result.categoryLabel}] ${path.basename(relPath)} — ${fmt(srcStat.size)} → ${fmt(result.outputSize)} (${pct}% saved, SSIM ${result.ssim.toFixed(3)})`);
        } catch (err) {
          addLog(job, 'warn', `Skipped ${path.basename(relPath)}: ${err.message}`);
          optTotal += srcStat.size;
        }
        job.metrics.processedImages = (job.metrics.processedImages || 0) + 1;
      } else if (VIDEO_EXTS.has(ext)) {
        const outExt = videoFormat === 'mp4' ? '.mp4' : '.webm';
        const outPath = path.join(outDir, baseName + outExt);
        try {
          const result = await processLocalVideo(srcPath, outPath, videoFormat === 'mp4' ? 'mp4' : 'webm');
          const saved = srcStat.size - result.outputSize;
          const pct = Math.round((saved / srcStat.size) * 100);
          optTotal += result.outputSize;
          addLog(job, 'info', `[Video] ${path.basename(relPath)} — ${fmt(srcStat.size)} → ${fmt(result.outputSize)} (${pct}% saved)`);
        } catch (err) {
          addLog(job, 'warn', `Skipped ${path.basename(relPath)}: ${err.message}`);
          optTotal += srcStat.size;
        }
        job.metrics.processedVideos = (job.metrics.processedVideos || 0) + 1;
      }

      job.progress = Math.round(
        ((job.metrics.processedImages || 0) + (job.metrics.processedVideos || 0)) /
        (job.metrics.totalImages + job.metrics.totalVideos) * 95
      );
    }

    job.metrics.originalSize = origTotal;
    job.metrics.optimizedSize = optTotal;
    job.metrics.savedPercent = origTotal > 0 ? Math.round((1 - optTotal / origTotal) * 100) : 0;

    // Zip the output
    addLog(job, 'info', 'Creating output zip...');
    const zipPath = path.join(os.tmpdir(), `mediamini-local-${job.id}.zip`);
    const zip = new AdmZip();
    addDirToZip(zip, tempDir, tempDir);
    zip.writeZip(zipPath);

    job.zipPath = zipPath;
    job.zipName = `mediamini-local-${job.id}.zip`;
    job.progress = 100;
    job.status = 'complete';
    addLog(job, 'info', `Done — ${job.metrics.savedPercent}% total size reduction`);
  } finally {
    // Clean up temp input files
    for (const { srcPath } of (job._tempFiles || [])) {
      try { fs.unlinkSync(srcPath); } catch (_) {}
    }
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

/**
 * Recursively collect image/video files from a path.
 * Handles: individual files, directories, zip archives.
 */
async function collectFiles(srcPath, basePath, out, addLog, job) {
  const stat = fs.statSync(srcPath);

  if (stat.isDirectory()) {
    const entries = fs.readdirSync(srcPath);
    for (const entry of entries) {
      await collectFiles(path.join(srcPath, entry), basePath, out, addLog, job);
    }
    return;
  }

  const ext = path.extname(srcPath).toLowerCase();

  // Expand zip archives
  if (ext === '.zip') {
    const expandDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mediamini-zip-'));
    try {
      const zip = new AdmZip(srcPath);
      zip.extractAllTo(expandDir, true);
      await collectFiles(expandDir, expandDir, out, addLog, job);
    } finally {
      fs.rmSync(expandDir, { recursive: true, force: true });
    }
    return;
  }

  if (IMAGE_EXTS.has(ext) || VIDEO_EXTS.has(ext)) {
    // Compute relative path from the base upload path
    const rel = path.relative(path.dirname(basePath), srcPath);
    out.push({ srcPath, relPath: rel });
  }
}

function addDirToZip(zip, dirPath, rootPath) {
  const entries = fs.readdirSync(dirPath);
  for (const entry of entries) {
    const full = path.join(dirPath, entry);
    const rel = path.relative(rootPath, full);
    if (fs.statSync(full).isDirectory()) {
      addDirToZip(zip, full, rootPath);
    } else {
      zip.addLocalFile(full, path.dirname(rel));
    }
  }
}

function fmt(bytes) {
  if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  return (bytes / 1024).toFixed(1) + ' KB';
}

module.exports = { runLocalJob };
