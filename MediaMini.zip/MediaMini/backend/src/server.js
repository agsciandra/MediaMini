'use strict';

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const os = require('os');
const multer = require('multer');
const { createJob, getJob, deleteJob, runJob } = require('./jobManager');
const { runLocalJob } = require('./localProcessor');

const app = express();
const PORT = 3001;

app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

// ── Multer: store uploads in a temp directory ─────────────────────────────────
const upload = multer({
  dest: os.tmpdir(),
  limits: { fileSize: 2 * 1024 * 1024 * 1024 }, // 2 GB max per file
});

// ── URL-based job ─────────────────────────────────────────────────────────────
app.post('/api/jobs', async (req, res) => {
  const { url, crawlMode } = req.body;
  if (!url || typeof url !== 'string') {
    return res.status(400).json({ error: 'Missing URL' });
  }

  const mode = crawlMode === 'page' ? 'page' : 'site';

  let parsed;
  try {
    parsed = new URL(url.startsWith('http') ? url : `https://${url}`);
  } catch (_) {
    return res.status(400).json({ error: 'Invalid URL' });
  }

  const blocked = ['localhost', '127.0.0.1', '0.0.0.0'];
  if (blocked.includes(parsed.hostname) || parsed.hostname.startsWith('192.168.') || parsed.hostname.startsWith('10.')) {
    return res.status(400).json({ error: 'Private/local URLs are not supported' });
  }

  const job = createJob();
  res.json({ jobId: job.id });
  runJob(job.id, parsed.href, mode).catch(() => {});
});

// ── Local file job ────────────────────────────────────────────────────────────
app.post('/api/local-jobs', upload.array('files', 500), async (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: 'No files uploaded' });
  }

  const imageFormat = req.body.imageFormat === 'png' ? 'png' : 'webp';
  const videoFormat = req.body.videoFormat === 'mp4' ? 'mp4' : 'webm';

  // Rename uploaded files to their original names so processors can detect extensions
  const uploadedPaths = [];
  const tempFiles = [];
  for (const file of req.files) {
    const origName = file.originalname || 'file';
    const ext = path.extname(origName).toLowerCase();
    const namedPath = file.path + ext;
    fs.renameSync(file.path, namedPath);
    uploadedPaths.push(namedPath);
    tempFiles.push(namedPath);
  }

  const job = createJob();
  job._tempFiles = tempFiles.map(p => ({ srcPath: p }));
  res.json({ jobId: job.id });

  // Run async
  (async () => {
    const addLog = (j, level, msg) => {
      const ts = new Date().toLocaleTimeString('en-US', { hour12: false });
      j.log.push(`${ts}  ${msg}`);
      if (j.log.length > 600) j.log.shift();
    };

    job.status = 'running';
    try {
      await runLocalJob(job, uploadedPaths, imageFormat, videoFormat, addLog);
      job.status = 'done';
      job.zipFilename = job.zipName;
    } catch (err) {
      job.status = 'error';
      job.error = err.message;
      addLog(job, 'error', `Fatal error: ${err.message}`);
    }
  })();
});

// ── Poll job status ───────────────────────────────────────────────────────────
app.get('/api/jobs/:id', (req, res) => {
  const job = getJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json({
    id: job.id,
    status: job.status,
    progress: job.progress,
    log: job.log,
    metrics: job.metrics,
    error: job.error,
    downloadReady: (job.status === 'done' || job.status === 'complete') && !!job.zipPath,
    zipFilename: job.zipFilename || job.zipName,
  });
});

// ── Download zip ──────────────────────────────────────────────────────────────
app.get('/api/jobs/:id/download', (req, res) => {
  const job = getJob(req.params.id);
  if (!job || !['done', 'complete'].includes(job.status) || !job.zipPath) {
    return res.status(400).json({ error: 'Not ready' });
  }
  if (!fs.existsSync(job.zipPath)) {
    return res.status(410).json({ error: 'File has expired' });
  }
  const filename = job.zipFilename || job.zipName || 'mediamini-output.zip';
  res.download(job.zipPath, filename, () => {
    setTimeout(() => {
      try { fs.unlinkSync(job.zipPath); } catch (_) {}
      deleteJob(job.id);
    }, 3000);
  });
});

// ── Delete job ────────────────────────────────────────────────────────────────
app.delete('/api/jobs/:id', (req, res) => {
  deleteJob(req.params.id);
  res.json({ ok: true });
});

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log('\n\x1b[32m  MediaMini is ready.\x1b[0m');
  console.log('\x1b[36m  Open this in your browser: \x1b[1mhttp://localhost:5173\x1b[0m\n');
});
