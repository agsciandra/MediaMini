'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const archiver = require('archiver');
const { v4: uuidv4 } = require('uuid');
const { crawlSite, crawlPage } = require('./crawler');
const { processImage } = require('./imageProcessor');
const { processVideo } = require('./videoProcessor');

const pLimit = require('p-limit');
const jobs = new Map();
const JOB_TTL = 30 * 60 * 1000; // 30 minutes of inactivity before cleanup
// Scale concurrency with CPU cores; keep a minimum of 4
const IMAGE_CONCURRENCY = Math.max(4, os.cpus().length * 2);

/**
 * Reset the TTL timer for a job. Called on every progress update so that
 * slow machines processing large sites never hit the cleanup timer mid-job.
 */
function resetTTL(job) {
  if (job._ttlTimer) clearTimeout(job._ttlTimer);
  job._ttlTimer = setTimeout(() => {
    const j = jobs.get(job.id);
    if (j) { cleanup(j); jobs.delete(job.id); }
  }, JOB_TTL);
}

function createJob() {
  const id = uuidv4();
  const job = {
    id, status: 'pending', progress: 0, log: [],
    metrics: {
      totalImages: 0, totalVideos: 0, pagesVisited: 0,
      processedImages: 0, processedVideos: 0,
      originalBytes: 0, finalBytes: 0,
      categories: { hero: 0, photo: 0, graphic: 0, icon: 0, background: 0 },
    },
    zipPath: null, zipFilename: null, error: null, tempDir: null, _ttlTimer: null,
  };
  jobs.set(id, job);
  resetTTL(job);
  return job;
}

function getJob(id) { return jobs.get(id) || null; }

function deleteJob(id) {
  const j = jobs.get(id);
  if (j) { cleanup(j); jobs.delete(id); }
}

function cleanup(job) {
  if (job.zipPath) try { fs.unlinkSync(job.zipPath); } catch (_) {}
  if (job.tempDir) try { fs.rmSync(job.tempDir, { recursive: true, force: true }); } catch (_) {}
}

function addLog(job, type, message) {
  job.log.push({ type, message, time: new Date().toISOString() });
  if (job.log.length > 600) job.log.shift();
}

function slugify(str) {
  return str.replace(/^https?:\/\//, '').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 80) || 'root';
}

/**
 * Preserve the original filename from a URL, only stripping the query string
 * and replacing characters that are illegal in file paths.
 * e.g. hero-portrait_2024.jpg?v=2  =>  hero-portrait_2024
 */
function safeFilename(url) {
  const raw = path.basename(url.split('?')[0]);
  const noExt = raw.replace(/\.[^.]+$/, '');
  const safe = noExt.replace(/[\/\\:*?"<>|]/g, '-').replace(/^-+|-+$/g, '').trim();
  return safe || 'file';
}

/**
 * Convert a page URL into a nested folder path that mirrors the URL structure.
 * e.g. https://alecsciandra.com/projects/mujin  =>  projects/mujin
 *      https://alecsciandra.com/                =>  home
 */
function urlToFolderPath(pageUrl) {
  try {
    const u = new URL(pageUrl);
    // Split pathname into clean segments, filtering empty strings
    const segments = u.pathname.split('/').filter(s => s.length > 0);
    if (segments.length === 0) return 'home';
    // Sanitize each segment: keep alphanumeric, hyphens, underscores, dots
    return segments.map(s => s.replace(/[^a-z0-9._-]/gi, '-').replace(/^-+|-+$/g, '').toLowerCase() || '_').join('/');
  } catch (_) {
    return slugify(pageUrl);
  }
}

function fmtBytes(b) {
  if (b < 1024) return `${b} B`;
  if (b < 1048576) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1048576).toFixed(2)} MB`;
}

// crawlMode: 'site' | 'page'
async function runJob(id, siteUrl, crawlMode = 'site') {
  const job = jobs.get(id);
  if (!job) return;
  job.status = 'running';

  const tempDir = path.join(os.tmpdir(), `mediamini-${id}`);
  fs.mkdirSync(tempDir, { recursive: true });
  job.tempDir = tempDir;

  try {
    // Phase 1: Crawl
    const modeLabel = crawlMode === 'page' ? 'single page' : 'full site';
    addLog(job, 'info', `Starting ${modeLabel} crawl: ${siteUrl}`);

    const onProgress = ({ type, message, visited }) => {
      addLog(job, type || 'info', message);
      if (visited) {
        job.metrics.pagesVisited = visited;
        job.progress = Math.min(10, Math.floor(visited / 2));
        resetTTL(job);
      }
    };

    const crawlFn = crawlMode === 'page' ? crawlPage : crawlSite;
    const { siteMap, pageCount } = await crawlFn(siteUrl, onProgress);

    job.metrics.pagesVisited = pageCount;
    addLog(job, 'info', `Crawl complete — ${pageCount} page${pageCount !== 1 ? 's' : ''} visited`);

    // Build deduplicated maps: url -> [pageDir, pageDir, ...]
    // Images and videos that appear on multiple pages are compressed once, then copied.
    const imageMap = new Map(); // imgUrl -> Set of pageDirs
    const videoMap = new Map(); // vidUrl -> Set of pageDirs

    for (const [pageUrl, { images, videos, is404 }] of Object.entries(siteMap)) {
      const pageDir = is404
        ? path.join(tempDir, '404')
        : path.join(tempDir, urlToFolderPath(pageUrl));
      fs.mkdirSync(pageDir, { recursive: true });
      for (const imgUrl of images) {
        if (!imageMap.has(imgUrl)) imageMap.set(imgUrl, new Set());
        imageMap.get(imgUrl).add(pageDir);
      }
      for (const vidUrl of videos) {
        if (!videoMap.has(vidUrl)) videoMap.set(vidUrl, new Set());
        videoMap.get(vidUrl).add(pageDir);
      }
    }

    const uniqueImages = [...imageMap.entries()];
    const uniqueVideos = [...videoMap.entries()];

    // Total unique assets (for progress) — copies don't count as work
    const totalMedia = uniqueImages.length + uniqueVideos.length || 1;
    let processed = 0;

    // Count total appearances (including duplicates) for metrics display
    const totalImageAppearances = [...imageMap.values()].reduce((s, v) => s + v.size, 0);
    const totalVideoAppearances = [...videoMap.values()].reduce((s, v) => s + v.size, 0);
    job.metrics.totalImages = totalImageAppearances;
    job.metrics.totalVideos = totalVideoAppearances;
    job.metrics.processedImages = 0;
    job.metrics.processedVideos = 0;

    const dupImgCount = totalImageAppearances - uniqueImages.length;
    const dupVidCount = totalVideoAppearances - uniqueVideos.length;
    addLog(job, 'info',
      `Discovered ${uniqueImages.length} unique image${uniqueImages.length !== 1 ? 's' : ''}` +
      (dupImgCount > 0 ? ` (${dupImgCount} shared across pages)` : '') +
      ` and ${uniqueVideos.length} unique video${uniqueVideos.length !== 1 ? 's' : ''}` +
      (dupVidCount > 0 ? ` (${dupVidCount} shared across pages)` : '')
    );

    // Phase 2a: Process unique images with p-limit, then copy to all other page folders
    const limit = pLimit(IMAGE_CONCURRENCY);
    await Promise.all(uniqueImages.map(([imgUrl, pageDirs], i) => limit(async () => {
      const base = safeFilename(imgUrl) || `image-${i}`;
      const dirs = [...pageDirs];
      const primaryDir = dirs[0];
      const copyDirs = dirs.slice(1);
      try {
        const r = await processImage(imgUrl, primaryDir, `${base}.webp`);
        job.metrics.originalBytes += r.originalSize;
        job.metrics.finalBytes += r.finalSize;
        job.metrics.processedImages += dirs.length; // count all appearances
        if (job.metrics.categories[r.category] !== undefined) job.metrics.categories[r.category]++;
        const pct = r.originalSize > 0 ? Math.round(((r.originalSize - r.finalSize) / r.originalSize) * 100) : 0;
        addLog(job, 'success',
          `[${r.categoryLabel}] ${base}.webp — ${fmtBytes(r.originalSize)} → ${fmtBytes(r.finalSize)} (${pct}% saved, SSIM ${r.ssim.toFixed(3)})` +
          (copyDirs.length > 0 ? ` · copied to ${copyDirs.length} other page${copyDirs.length !== 1 ? 's' : ''}` : '')
        );
        // Copy compressed file into every other page folder it appears in
        for (const dir of copyDirs) {
          fs.mkdirSync(dir, { recursive: true });
          fs.copyFileSync(r.outputPath, path.join(dir, `${base}.webp`));
        }
      } catch (err) {
        addLog(job, 'warn', `Skipped ${safeFilename(imgUrl)}: ${err.message}`);
      }
      processed++;
      job.progress = 10 + Math.floor((processed / totalMedia) * 85);
      resetTTL(job);
    })));

    // Phase 2b: Process unique videos sequentially, copy to other page folders
    for (const [vidUrl, pageDirs] of uniqueVideos) {
      const base = safeFilename(vidUrl) || `video-${processed}`;
      const dirs = [...pageDirs];
      const primaryDir = dirs[0];
      const copyDirs = dirs.slice(1);
      try {
        const r = await processVideo(vidUrl, primaryDir, `${base}.webm`, msg => addLog(job, 'info', msg));
        job.metrics.originalBytes += r.originalSize;
        job.metrics.finalBytes += r.finalSize;
        job.metrics.processedVideos += dirs.length;
        const pct = r.originalSize > 0 ? Math.round(((r.originalSize - r.finalSize) / r.originalSize) * 100) : 0;
        addLog(job, 'success',
          `[Video] ${base}.webm — ${fmtBytes(r.originalSize)} → ${fmtBytes(r.finalSize)} (${pct}% saved)` +
          (copyDirs.length > 0 ? ` · copied to ${copyDirs.length} other page${copyDirs.length !== 1 ? 's' : ''}` : '')
        );
        for (const dir of copyDirs) {
          fs.mkdirSync(dir, { recursive: true });
          fs.copyFileSync(r.outputPath, path.join(dir, `${base}.webm`));
        }
      } catch (err) {
        addLog(job, 'warn', `Skipped ${safeFilename(vidUrl)}: ${err.message}`);

      }
      processed++;
      job.progress = 10 + Math.floor((processed / totalMedia) * 85);
      resetTTL(job);
    }

    // Phase 3: Zip
    addLog(job, 'info', 'Building archive…');
    job.progress = 96;
    resetTTL(job);
    const zipFilename = `${slugify(siteUrl)}-mediamini.zip`;
    const zipPath = path.join(os.tmpdir(), `mediamini-zip-${id}.zip`);
    await zipDir(tempDir, zipPath);

    job.zipPath = zipPath;
    job.zipFilename = zipFilename;
    job.status = 'done';
    job.progress = 100;
    resetTTL(job);

    const totalSaved = job.metrics.originalBytes - job.metrics.finalBytes;
    const totalPct = job.metrics.originalBytes > 0 ? Math.round((totalSaved / job.metrics.originalBytes) * 100) : 0;
    addLog(job, 'success',
      `Complete. ${fmtBytes(job.metrics.originalBytes)} → ${fmtBytes(job.metrics.finalBytes)} — ${totalPct}% total reduction`
    );

    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}

  } catch (err) {
    job.status = 'error';
    job.error = err.message;
    addLog(job, 'error', `Fatal error: ${err.message}`);
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}
  }
}

function zipDir(src, dest) {
  return new Promise((resolve, reject) => {
    const out = fs.createWriteStream(dest);
    // Level 1: WebP and WebM are already compressed — higher levels waste CPU for no gain
    const arc = archiver('zip', { zlib: { level: 1 } });
    out.on('close', resolve);
    arc.on('error', reject);
    arc.pipe(out);
    arc.directory(src, false);
    arc.finalize();
  });
}

module.exports = { createJob, getJob, deleteJob, runJob };
