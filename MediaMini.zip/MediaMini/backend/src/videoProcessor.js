'use strict';

const ffmpeg = require('fluent-ffmpeg');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { v4: uuidv4 } = require('uuid');

// Use ffmpeg-static if available, otherwise system ffmpeg
try { const s = require('ffmpeg-static'); if (s) ffmpeg.setFfmpegPath(s); } catch (_) {}

/**
 * CRF quality floors per video content type.
 * Lower CRF = higher quality / larger file.
 * We start at CRF_START and step up, but never exceed the floor for that type.
 *
 * Content types (inferred from duration + resolution):
 *   hero    — short, high-res, prominent (e.g. reel, showreel)  → floor 30
 *   ambient — looping background, lower visual priority          → floor 38
 *   general — everything else                                    → floor 34
 *
 * VP9 reference: CRF 33 ≈ visually lossless for web; CRF 52 = worst quality.
 */
const CRF_FLOORS = {
  hero:    30,
  ambient: 38,
  general: 34,
};

const CRF_START = 28; // always try a high-quality first pass
const CRF_STEP  = 3;

/**
 * Classify a video by content type based on its metadata.
 * @param {{ duration: number, width: number|null }} meta
 * @returns {'hero'|'ambient'|'general'}
 */
function classifyVideo(meta) {
  const { duration, width } = meta;
  // Short, high-resolution → likely a hero/reel
  if (duration <= 30 && width && width >= 1280) return 'hero';
  // Very long or low-res → likely ambient/background
  if (duration > 60 || (width && width < 640)) return 'ambient';
  return 'general';
}

async function processVideo(videoUrl, outputDir, filename, onProgress) {
  const ext = path.extname(videoUrl.split('?')[0]) || '.mp4';
  const tmpIn = path.join(os.tmpdir(), `mm-in-${uuidv4()}${ext}`);
  const outPath = path.join(outputDir, filename);

  onProgress(`Downloading: ${path.basename(videoUrl.split('?')[0])}`);
  const res = await axios.get(videoUrl, {
    responseType: 'stream', timeout: 120000,
    maxContentLength: 500 * 1024 * 1024,
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; MediaMini/1.0)' },
  });

  await new Promise((resolve, reject) => {
    const w = fs.createWriteStream(tmpIn);
    res.data.pipe(w);
    w.on('finish', resolve);
    w.on('error', reject);
  });

  const originalSize = fs.statSync(tmpIn).size;
  const meta = await getVideoMeta(tmpIn);
  const contentType = classifyVideo(meta);
  const crfFloor = CRF_FLOORS[contentType];

  let finalSize = originalSize;
  let usedCrf = CRF_START;

  for (let crf = CRF_START; crf <= crfFloor; crf += CRF_STEP) {
    usedCrf = crf;
    onProgress(`[${contentType}] Converting to WebM (CRF ${crf}): ${filename}`);
    const tmpOut = path.join(os.tmpdir(), `mm-out-${uuidv4()}.webm`);
    let committed = false;
    try {
      await convertToWebM(tmpIn, tmpOut, crf, meta);
      const candidate = fs.statSync(tmpOut).size;
      // Accept if file shrank vs original, or we've hit the quality floor
      if (candidate < originalSize || crf >= crfFloor) {
        finalSize = candidate;
        fs.copyFileSync(tmpOut, outPath);
        committed = true;
        break;
      }
    } catch (err) {
      throw new Error(`Video conversion failed: ${err.message}`);
    } finally {
      if (!committed) try { fs.unlinkSync(tmpOut); } catch (_) {}
    }
  }

  try { fs.unlinkSync(tmpIn); } catch (_) {}
  return { outputPath: outPath, originalSize, finalSize, contentType, crf: usedCrf };
}

function convertToWebM(input, output, crf, meta) {
  return new Promise((resolve, reject) => {
    let cmd = ffmpeg(input)
      .outputOptions([
        '-c:v libvpx-vp9', `-crf ${crf}`, '-b:v 0',
        '-c:a libopus', '-b:a 96k',
        '-deadline good', '-cpu-used 4', '-row-mt 1', '-threads 4',
      ])
      .format('webm');
    if (meta.width && meta.width > 1920) cmd = cmd.outputOptions(['-vf scale=1920:-2']);
    cmd.save(output).on('end', resolve).on('error', reject);
  });
}

function getVideoMeta(file) {
  return new Promise(resolve => {
    ffmpeg.ffprobe(file, (err, meta) => {
      if (err) return resolve({ duration: 60, width: null });
      const v = (meta.streams || []).find(s => s.codec_type === 'video');
      resolve({ duration: meta.format?.duration || 60, width: v?.width || null });
    });
  });
}

/**
 * processLocalVideo — same CRF pipeline but reads from a local file path
 * and supports both WebM and MP4 output.
 */
async function processLocalVideo(inputPath, outputPath, format = 'webm') {
  const originalSize = fs.statSync(inputPath).size;
  const meta = await getVideoMeta(inputPath);
  const contentType = classifyVideo(meta);
  const crfFloor = CRF_FLOORS[contentType];

  let outputSize = originalSize;

  for (let crf = CRF_START; crf <= crfFloor; crf += CRF_STEP) {
    const tmpOut = path.join(os.tmpdir(), `mm-local-${uuidv4()}.${format}`);
    let committed = false;
    try {
      if (format === 'mp4') {
        await convertToMp4(inputPath, tmpOut, crf, meta);
      } else {
        await convertToWebM(inputPath, tmpOut, crf, meta);
      }
      const candidate = fs.statSync(tmpOut).size;
      if (candidate < originalSize || crf >= crfFloor) {
        outputSize = candidate;
        fs.copyFileSync(tmpOut, outputPath);
        committed = true;
        break;
      }
    } catch (err) {
      throw new Error(`Video conversion failed: ${err.message}`);
    } finally {
      if (!committed) try { fs.unlinkSync(tmpOut); } catch (_) {}
    }
  }

  return { outputPath, originalSize, outputSize, contentType };
}

function convertToMp4(input, output, crf, meta) {
  return new Promise((resolve, reject) => {
    let cmd = ffmpeg(input)
      .outputOptions([
        '-c:v libx264', `-crf ${crf}`, '-preset fast',
        '-c:a aac', '-b:a 128k',
        '-movflags +faststart',
      ])
      .format('mp4');
    if (meta.width && meta.width > 1920) cmd = cmd.outputOptions(['-vf scale=1920:-2']);
    cmd.save(output).on('end', resolve).on('error', reject);
  });
}

module.exports = { processVideo, processLocalVideo };
