#!/bin/bash
# MediaMini Launcher
# Right-click → Open the first time. After that, double-click works normally.

# ── Resolve the real path of this script (handles symlinks) ──────────────────
SOURCE="${BASH_SOURCE[0]}"
while [ -L "$SOURCE" ]; do
  DIR="$(cd -P "$(dirname "$SOURCE")" && pwd)"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
DIR="$(cd -P "$(dirname "$SOURCE")" && pwd)"

clear
echo "======================================================="
echo "  MediaMini"
echo "======================================================="
echo ""

# ── Strip quarantine from the whole folder (silences future warnings) ─────────
xattr -rd com.apple.quarantine "$DIR" 2>/dev/null

# ── Find Node.js ──────────────────────────────────────────────────────────────
export PATH="$PATH:/usr/local/bin:/opt/homebrew/bin:/usr/bin"
if [ -s "$HOME/.nvm/nvm.sh" ]; then source "$HOME/.nvm/nvm.sh"; fi

if ! command -v node &>/dev/null; then
  echo "  ERROR: Node.js is not installed."
  echo ""
  echo "  Install it from: https://nodejs.org/"
  echo "  Download the LTS version, run the installer, then relaunch MediaMini."
  echo ""
  open "https://nodejs.org/"
  echo "  Press any key to close..."
  read -n 1
  exit 1
fi

echo "  Node.js $(node --version) found"
echo ""

# ── First-time backend setup ──────────────────────────────────────────────────
if [ ! -d "$DIR/backend/node_modules" ]; then
  echo "  First-time setup: installing backend packages..."
  echo "  (This only happens once — about 1 minute)"
  echo ""
  cd "$DIR/backend" && npm install
  if [ $? -ne 0 ]; then
    echo ""
    echo "  ERROR: Installation failed. Check your internet connection and try again."
    echo "  Press any key to close..."
    read -n 1; exit 1
  fi
  echo ""
  echo "  Installing browser engine for the crawler..."
  echo "  (One-time download — about 100 MB)"
  echo ""
  cd "$DIR/backend" && npx playwright install chromium
  echo ""
fi

# ── First-time frontend setup ─────────────────────────────────────────────────
if [ ! -d "$DIR/frontend/node_modules" ]; then
  echo "  Installing frontend packages..."
  cd "$DIR/frontend" && npm install --silent
  echo ""
fi

# ── Start backend ─────────────────────────────────────────────────────────────
echo "  Starting engine..."
cd "$DIR/backend"
node src/server.js &
BPID=$!

# Wait for backend to be ready (poll port 3001)
for i in $(seq 1 20); do
  sleep 1
  if curl -s http://localhost:3001/api/health >/dev/null 2>&1; then
    break
  fi
done

# ── Start frontend ────────────────────────────────────────────────────────────
cd "$DIR/frontend"
npm run dev &
FPID=$!

# Give Vite a moment to bind the port, then open browser as a fallback
sleep 3
open "http://localhost:5173" 2>/dev/null

echo ""
echo "======================================================="
echo "  MediaMini is running."
echo ""
echo "  Browser: http://localhost:5173"
echo ""
echo "  Close this window to stop MediaMini."
echo "======================================================="
echo ""

# ── Keep the script alive until the user closes the window ───────────────────
# Trap any exit signal and kill both child processes cleanly
cleanup() {
  echo ""
  echo "  Stopping MediaMini..."
  kill $BPID $FPID 2>/dev/null
  wait $BPID $FPID 2>/dev/null
  exit 0
}
trap cleanup INT TERM

# Block forever — the user must close the Terminal window to stop
while kill -0 $BPID 2>/dev/null && kill -0 $FPID 2>/dev/null; do
  sleep 5
done

# If either process died unexpectedly, report it and keep the window open
echo ""
echo "  WARNING: A MediaMini process stopped unexpectedly."
echo "  Check above for any error messages."
echo ""
echo "  Press any key to close this window..."
read -n 1
cleanup
