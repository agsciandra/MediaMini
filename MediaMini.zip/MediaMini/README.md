# MediaMini

Crawls your website, converts every image to WebP and every video to WebM, and compresses each file using perceptual quality analysis — so they look identical on screen but weigh far less. Everything runs locally on your Mac. No files are uploaded anywhere.

---

## First-time setup

### 1. Install Node.js (once, ever)

Go to [nodejs.org](https://nodejs.org) and download the **LTS** version. Run the installer. Done.

### 2. Allow MediaMini to run (once, ever)

macOS blocks apps that aren't signed with a paid Apple developer certificate. Here's how to allow it:

1. Double-click **Start MediaMini** — when the warning appears, click **Done**
2. Open **System Settings** → **Privacy & Security**
3. Scroll down until you see *"Start MediaMini was blocked…"*
4. Click **Open Anyway** → enter your Mac password → click **Open Anyway** again
5. Double-click **Start MediaMini** one more time — it opens normally

After this one-time step, double-clicking works every time with no warnings.

---

## Every day use

1. Double-click **Start MediaMini** from the `MediaMini` folder on your Desktop
2. A Terminal window opens — leave it running in the background (don't close it)
3. When the Terminal shows `Open your browser to: http://localhost:5173`, click that link
4. Choose **Full Site** or **Single Page**, paste your URL, and click **Run**
5. When the job finishes, your optimized files download automatically as a zip
6. Close the Terminal window when you're done

> **First launch only:** MediaMini installs its dependencies (~100 MB) and downloads a browser engine. This takes 1–2 minutes and never happens again.

---

## What the output looks like

The zip mirrors your site's URL structure exactly:

```
home/               ← root page (/)
  hero.webp
projects/
  thumbnail.webp
  mujin/
    cover.webp
about/
  headshot.webp
```

Drop the folders directly into your site's asset directory as replacements.

---

## How compression works

Each image is classified before being compressed. The category determines the quality target:

| Category | Examples | Quality target |
|---|---|---|
| Hero Image | Large banner photos | Highest — very conservative |
| Photograph | Portfolio images | High |
| Graphic / Illustration | Flat artwork, logos | Moderate |
| Icon / UI Element | Small or simple images | Aggressive |
| Background Texture | Large, low-detail fills | Aggressive |

After compression, SSIM scoring compares the output against the original pixel-by-pixel. If the visual difference is perceptible, the file is kept at a higher quality floor. Videos use the same perceptual approach via CRF scoring.

---

## Troubleshooting

**"Cannot reach the MediaMini engine"** — The Terminal window closed or the engine didn't finish starting. Re-launch Start MediaMini and wait for the URL to appear before opening the browser.

**Stuck on "Installing packages…"** — First-time setup is downloading dependencies. Give it a couple of minutes and make sure you have an internet connection.

**A file was skipped** — Check the Activity Log for the reason. Usually the file was unreachable (behind a login, CDN restriction, or not a supported format).

**Nothing downloaded** — Check your Downloads folder. If the file isn't there, use the **Download again** link in the dashboard.

**Videos were skipped** — MediaMini can only process videos hosted directly on your site. YouTube embeds, Vimeo, and other third-party video players are not supported.
